# GARBSHIT: Garb's Self-Indulgent Joker Pack

## ![Garb's Soul Sprite](https://github.com/Gainumki/GARBSHIT/blob/main/garb.png) > Hi! I'm Garb! I mod Balala!

## The Mod
![Title Screen](https://github.com/user-attachments/assets/172379c9-fa6a-4af8-ba96-0fc226ce0ebe)

I make these Jokers (And misc stuff too as of now) for myself but i figure people might enjoy them, so they're available to download!

There are currently 45 Jokers in this mod, more will be on the way :]

V2.0 adds Stamps, a new type of consumable that work by exchanging jokers for stuff, try them out!
There's also a few consumables and enhancements, more of that coming soon too, stay tuned!!

Check the repository every once in a while for updates :33

Every Joker and art in this mod is made by me unless stated otherwise

## Contents
- 45 Jokers (8 Legendaries)
- 2 Tarots
- 2 Card Enhancements
- 2 Vouchers
- 2 Spectrals
- 4 Decks
- 12 Stamps
- 1 New Booster Type
- 1 Tag
- 4 Sleeves (Cross-mod content for [CardSleeves](https://github.com/larswijn/CardSleeves/releases/latest))
  
## Special Thanks
Special thanks to Localthunk for making Balatro and to the Balatro discord (especially the people over on #modding-dev) for helping me whenever I had any issues, y'all the best >8]





