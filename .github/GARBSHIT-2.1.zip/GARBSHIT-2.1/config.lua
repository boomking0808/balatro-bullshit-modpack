return {
	["fukkireta"] = true,
	["title"] = true,
	["on_card_credits"] = true,
}